require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["user", "admin"], default: "user" }
}, { timestamps: true });

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, default: "" },
  price: { type: Number, required: true, min: 0 },
  image: { type: String, default: "" },
  category: { type: String, default: "General" },
  stock: { type: Number, default: 0, min: 0 }
}, { timestamps: true });

const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
    name: String,
    price: Number,
    quantity: Number
  }],
  total: { type: Number, required: true },
  status: { type: String, enum: ["Placed", "Processing", "Shipped", "Delivered", "Cancelled"], default: "Placed" },
  shippingAddress: { type: String, required: true }
}, { timestamps: true });

const User = mongoose.model("User", userSchema);
const Product = mongoose.model("Product", productSchema);
const Order = mongoose.model("Order", orderSchema);

function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ message: "Login required" });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid or expired token" });
  }
}
function adminOnly(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
  next();
}

app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 6)
      return res.status(400).json({ message: "Enter name, email and a password of at least 6 characters" });
    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ message: "Email is already registered" });
    const user = await User.create({ name, email, password: await bcrypt.hash(password, 10) });
    res.status(201).json({ message: "Account created", user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { res.status(500).json({ message: "Could not register account" }); }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const user = await User.findOne({ email: (req.body.email || "").toLowerCase() });
    if (!user || !(await bcrypt.compare(req.body.password || "", user.password)))
      return res.status(401).json({ message: "Incorrect email or password" });
    const token = jwt.sign({ id: user._id, name: user.name, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch { res.status(500).json({ message: "Could not log in" }); }
});

app.get("/api/products", async (req, res) => {
  try {
    const filter = {};
    if (req.query.search) filter.name = { $regex: req.query.search, $options: "i" };
    if (req.query.category) filter.category = req.query.category;
    res.json(await Product.find(filter).sort({ createdAt: -1 }));
  } catch { res.status(500).json({ message: "Could not load products" }); }
});

app.post("/api/products", auth, adminOnly, async (req, res) => {
  try {
    const { name, description, price, image, category, stock } = req.body;
    if (!name || !Number.isFinite(Number(price)) || Number(price) < 0)
      return res.status(400).json({ message: "Product name and a valid price are required" });
    const product = await Product.create({ name, description, price, image, category, stock });
    res.status(201).json(product);
  } catch { res.status(500).json({ message: "Could not create product" }); }
});

app.put("/api/products/:id", auth, adminOnly, async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  } catch { res.status(400).json({ message: "Invalid product data" }); }
});

app.delete("/api/products/:id", auth, adminOnly, async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json({ message: "Product deleted" });
  } catch { res.status(400).json({ message: "Invalid product ID" }); }
});

app.post("/api/orders", auth, async (req, res) => {
  try {
    const { items, shippingAddress } = req.body;
    if (!Array.isArray(items) || items.length === 0 || !shippingAddress)
      return res.status(400).json({ message: "Cart items and shipping address are required" });
    const orderItems = [];
    let total = 0;
    for (const item of items) {
      const product = await Product.findById(item.productId);
      const quantity = Math.floor(Number(item.quantity));
      if (!product || !Number.isInteger(quantity) || quantity < 1)
        return res.status(400).json({ message: "Invalid product or quantity" });
      if (product.stock < quantity)
        return res.status(400).json({ message: `Not enough stock for ${product.name}` });
      orderItems.push({ product: product._id, name: product.name, price: product.price, quantity });
      total += product.price * quantity;
    }
    for (const item of orderItems) {
      await Product.findByIdAndUpdate(item.product, { $inc: { stock: -item.quantity } });
    }
    const order = await Order.create({ user: req.user.id, items: orderItems, total, shippingAddress });
    res.status(201).json(order);
  } catch { res.status(500).json({ message: "Could not place order" }); }
});

app.get("/api/orders/my", auth, async (req, res) => {
  try { res.json(await Order.find({ user: req.user.id }).sort({ createdAt: -1 })); }
  catch { res.status(500).json({ message: "Could not load orders" }); }
});

app.get("/api/orders", auth, adminOnly, async (req, res) => {
  try { res.json(await Order.find().populate("user", "name email").sort({ createdAt: -1 })); }
  catch { res.status(500).json({ message: "Could not load orders" }); }
});

app.patch("/api/orders/:id/status", auth, adminOnly, async (req, res) => {
  const allowed = ["Placed", "Processing", "Shipped", "Delivered", "Cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ message: "Invalid order status" });
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
    if (!order) return res.status(404).json({ message: "Order not found" });
    res.json(order);
  } catch { res.status(400).json({ message: "Invalid order ID" }); }
});

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

const PORT = process.env.PORT || 5000;
if (!process.env.JWT_SECRET) {
  console.error("Set JWT_SECRET in your .env file");
  process.exit(1);
}
mongoose.connect(process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/shopdb")
  .then(() => app.listen(PORT, () => console.log(`Store running at http://localhost:${PORT}`)))
  .catch(err => { console.error("MongoDB connection failed:", err.message); process.exit(1); });
