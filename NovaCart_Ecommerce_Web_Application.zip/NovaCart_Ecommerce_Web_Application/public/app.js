const API = "/api";
let token = localStorage.getItem("shopToken") || "";
let currentUser = JSON.parse(localStorage.getItem("shopUser") || "null");
let products = [], cart = JSON.parse(localStorage.getItem("shopCart") || "[]"), editingId = null, registerMode = false;
const $ = id => document.getElementById(id);
const money = n => "₹" + Number(n).toFixed(2);
async function request(url, options={}) {
  const headers = { "Content-Type":"application/json", ...(options.headers||{}) };
  if (token) headers.Authorization = "Bearer " + token;
  const res = await fetch(API + url, {...options, headers});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
}
function saveCart(){localStorage.setItem("shopCart",JSON.stringify(cart));renderCartCount();}
function renderUser(){
  $("welcome").textContent=currentUser ? "Hi, "+currentUser.name.split(" ")[0] : "";
  $("authButton").textContent=currentUser ? "Logout" : "Login";
  $("ordersLink").classList.toggle("hidden",!currentUser);
  $("adminLink").classList.toggle("hidden",!currentUser || currentUser.role!=="admin");
  $("orders").classList.toggle("hidden",!currentUser);
  $("admin").classList.toggle("hidden",!currentUser || currentUser.role!=="admin");
}
async function loadProducts(){
  try{
    products=await request("/products?search="+encodeURIComponent($("search").value));
    $("products").innerHTML=products.length?products.map(p=>`<article class="product-card"><div class="product-image">${p.image?`<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" onerror="this.remove()">`:"✳"}</div><div class="product-info"><small>${escapeHtml(p.category||"GENERAL")}</small><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.description||"A useful everyday find.")}</p><div class="product-foot"><strong>${money(p.price)}</strong><button class="primary" onclick="addToCart('${p._id}')" ${p.stock<1?"disabled":""}>${p.stock<1?"Out of stock":"Add to cart"}</button></div><small>${p.stock} in stock</small></div></article>`).join(""):'<p class="empty">No products found yet. Admin can add products from the dashboard.</p>';
    if(currentUser?.role==="admin") renderAdminProducts();
  }catch(e){$("products").innerHTML='<p class="empty">Unable to load products. Check that the server and database are running.</p>';}
}
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function addToCart(id){
  const p=products.find(x=>x._id===id);if(!p)return;
  const found=cart.find(x=>x.productId===id);
  if(found){if(found.quantity>=p.stock)return alert("Stock limit reached");found.quantity++;}
  else cart.push({productId:id,name:p.name,price:p.price,quantity:1,stock:p.stock});
  saveCart();renderCart();toggleCart(true);
}
function renderCartCount(){$("cartCount").textContent=cart.reduce((s,x)=>s+x.quantity,0);}
function renderCart(){
  $("cartItems").innerHTML=cart.length?cart.map(x=>`<div class="cart-row"><div><b>${escapeHtml(x.name)}</b><small>${money(x.price)} × ${x.quantity}</small></div><div><button onclick="changeQty('${x.productId}',-1)">−</button><button onclick="changeQty('${x.productId}',1)">+</button><button class="danger" onclick="removeCart('${x.productId}')">×</button></div></div>`).join(""):'<p class="empty">Your cart is empty.</p>';
  $("cartTotal").textContent=money(cart.reduce((s,x)=>s+x.price*x.quantity,0));
}
function changeQty(id,delta){const x=cart.find(i=>i.productId===id);if(!x)return;x.quantity+=delta;if(x.quantity<1)cart=cart.filter(i=>i.productId!==id);if(x.quantity>x.stock)x.quantity=x.stock;saveCart();renderCart();}
function removeCart(id){cart=cart.filter(x=>x.productId!==id);saveCart();renderCart();}
function toggleCart(force){const open=force===true||$("cartDrawer").classList.contains("hidden");$("cartDrawer").classList.toggle("hidden",!open);$("overlay").classList.toggle("hidden",!open);if(open)renderCart();}
function openAuth(){if(currentUser){if(confirm("Log out of NovaCart?")){token="";currentUser=null;localStorage.removeItem("shopToken");localStorage.removeItem("shopUser");renderUser();}return;}$("authModal").classList.remove("hidden");}
function closeAuth(){$("authModal").classList.add("hidden");$("authMessage").textContent="";}
function switchAuth(){registerMode=!registerMode;$("authTitle").textContent=registerMode?"Create account":"Sign in";$("authName").classList.toggle("hidden",!registerMode);$("authPassword").placeholder=registerMode?"Password (min 6 characters)":"Password";$("authSubmit").textContent=registerMode?"Create account":"Login";$("authSwitch").innerHTML=registerMode?'Already registered? <a href="#" onclick="switchAuth();return false">Sign in</a>':'New here? <a href="#" onclick="switchAuth();return false">Create an account</a>';}
$("authForm").addEventListener("submit",async e=>{
  e.preventDefault();$("authMessage").textContent="";
  try{
    const body={email:$("authEmail").value,password:$("authPassword").value};
    if(registerMode){body.name=$("authName").value;await request("/auth/register",{method:"POST",body:JSON.stringify(body)});registerMode=false;switchAuth();}
    const data=await request("/auth/login",{method:"POST",body:JSON.stringify(body)});
    token=data.token;currentUser=data.user;localStorage.setItem("shopToken",token);localStorage.setItem("shopUser",JSON.stringify(currentUser));closeAuth();renderUser();loadOrders();if(currentUser.role==="admin")loadAdmin();
  }catch(err){$("authMessage").textContent=err.message;}
});
async function checkout(){
  if(!currentUser){toggleCart(false);openAuth();return alert("Please log in before checkout.");}
  const shippingAddress=$("shippingAddress").value.trim();if(!shippingAddress)return alert("Enter your delivery address.");
  try{const order=await request("/orders",{method:"POST",body:JSON.stringify({shippingAddress,items:cart.map(x=>({productId:x.productId,quantity:x.quantity}))})});cart=[];saveCart();renderCart();toggleCart(false);$("shippingAddress").value="";alert("Order placed! Order ID: "+order._id);loadProducts();loadOrders();}
  catch(e){alert(e.message);}
}
async function loadOrders(){
  if(!currentUser)return;
  try{const orders=await request("/orders/my");$("myOrders").innerHTML=orders.length?orders.map(o=>`<div class="order-card"><div><b>Order #${o._id.slice(-8).toUpperCase()}</b><small>${new Date(o.createdAt).toLocaleString()} · ${o.items.map(i=>escapeHtml(i.name)+" × "+i.quantity).join(", ")}</small><small>${escapeHtml(o.shippingAddress)}</small></div><div style="text-align:right"><b>${money(o.total)}</b><p><span class="status">${o.status}</span></p></div></div>`).join(""):'<p class="empty">You have not placed an order yet.</p>';}
  catch(e){$("myOrders").textContent=e.message;}
}
function renderAdminProducts(){
  $("adminProducts").innerHTML=products.length?products.map(p=>`<div class="admin-row"><div><b>${escapeHtml(p.name)}</b><small>${money(p.price)} · Stock ${p.stock}</small></div><div><button class="outline" onclick="editProduct('${p._id}')">Edit</button><button class="danger" onclick="deleteProduct('${p._id}')">Delete</button></div></div>`).join(""):'<p class="empty">No products added.</p>';
}
function editProduct(id){const p=products.find(x=>x._id===id);if(!p)return;editingId=id;const f=$("productForm");["name","description","price","stock","category","image"].forEach(k=>f.elements[k].value=p[k]??"");$("productFormTitle").textContent="Edit product";$("cancelEdit").classList.remove("hidden");$("admin").scrollIntoView({behavior:"smooth"});}
function resetProductForm(){editingId=null;$("productForm").reset();$("productForm").elements.stock.value=10;$("productFormTitle").textContent="Add a product";$("cancelEdit").classList.add("hidden");}
$("productForm").addEventListener("submit",async e=>{
  e.preventDefault();const f=e.target;const body={};["name","description","price","stock","category","image"].forEach(k=>body[k]=f.elements[k].value);
  body.price=Number(body.price);body.stock=Number(body.stock);
  try{await request("/products"+(editingId?"/"+editingId:""),{method:editingId?"PUT":"POST",body:JSON.stringify(body)});resetProductForm();await loadProducts();}catch(err){alert(err.message);}
});
async function deleteProduct(id){if(!confirm("Delete this product?"))return;try{await request("/products/"+id,{method:"DELETE"});loadProducts();}catch(e){alert(e.message);}}
async function loadAdmin(){
  try{const orders=await request("/orders");$("allOrders").innerHTML=orders.length?orders.map(o=>`<div class="order-card"><div><b>${escapeHtml(o.user?.name||"Customer")} · ${money(o.total)}</b><small>${escapeHtml(o.user?.email||"")} · ${o.items.map(i=>escapeHtml(i.name)+" × "+i.quantity).join(", ")}</small><small>${escapeHtml(o.shippingAddress)}</small></div><select aria-label="Order status" onchange="updateStatus('${o._id}',this.value)">${["Placed","Processing","Shipped","Delivered","Cancelled"].map(s=>`<option ${s===o.status?"selected":""}>${s}</option>`).join("")}</select></div>`).join(""):'<p class="empty">No customer orders yet.</p>';}
  catch(e){$("allOrders").textContent=e.message;}
}
async function updateStatus(id,status){try{await request("/orders/"+id+"/status",{method:"PATCH",body:JSON.stringify({status})});loadAdmin();}catch(e){alert(e.message);}}
renderUser();renderCartCount();renderCart();loadProducts();if(currentUser){loadOrders();if(currentUser.role==="admin")loadAdmin();}
