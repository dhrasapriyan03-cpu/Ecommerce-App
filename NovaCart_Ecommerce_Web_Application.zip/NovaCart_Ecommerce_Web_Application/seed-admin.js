require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const schema = new mongoose.Schema({
  name: String, email: { type: String, unique: true }, password: String,
  role: { type: String, default: "admin" }
});
const User = mongoose.model("User", schema);
(async () => {
  if (!process.env.MONGODB_URI || !process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) {
    console.error("Set MONGODB_URI, ADMIN_EMAIL and ADMIN_PASSWORD in .env");
    process.exit(1);
  }
  await mongoose.connect(process.env.MONGODB_URI);
  const email = process.env.ADMIN_EMAIL.toLowerCase();
  const password = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
  await User.findOneAndUpdate({ email }, {
    name: process.env.ADMIN_NAME || "Store Admin", email, password, role: "admin"
  }, { upsert: true, new: true, setDefaultsOnInsert: true });
  console.log(`Admin account ready: ${email}`);
  await mongoose.disconnect();
})().catch(err => { console.error(err); process.exit(1); });
