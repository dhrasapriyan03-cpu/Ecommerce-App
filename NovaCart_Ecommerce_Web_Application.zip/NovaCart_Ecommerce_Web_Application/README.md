# NovaCart – E-Commerce Web Application

A responsive full-stack demo store built with **HTML, CSS, JavaScript, Node.js, Express and MongoDB**.

## Features

- Product catalogue with search
- Shopping cart with quantity controls
- Demo checkout and order creation
- User registration and login using JWT
- Admin/User role-based access
- Admin product create, edit and delete
- Customer order history and tracking
- Admin order list and status updates
- Responsive layout for desktop and mobile

> Checkout is a demonstration flow. It does not collect payment details or process real payments.

## Requirements

- Node.js 18+
- MongoDB Community Server running locally, or a MongoDB Atlas connection string

## Setup

1. Extract the ZIP and open the project folder in VS Code.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. Update `MONGODB_URI` and set a long, private `JWT_SECRET`.
5. Start MongoDB if you use a local database.
6. Create the admin account:

   ```bash
   npm run seed:admin
   ```

   The admin email and password come from `.env` (`ADMIN_EMAIL`, `ADMIN_PASSWORD`). Change the example password before running this command.

7. Start the app:

   ```bash
   npm start
   ```

8. Open **http://localhost:5000** in your browser.

## Admin and user access

- Register a normal account using the Login button. New registrations always receive the `user` role.
- Sign in with the admin credentials from `.env` to manage products and orders.
- Never expose your `.env` file or JWT secret.

## API overview

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register user |
| POST | `/api/auth/login` | Public | Login |
| GET | `/api/products` | Public | List/search products |
| POST | `/api/products` | Admin | Add product |
| PUT | `/api/products/:id` | Admin | Update product |
| DELETE | `/api/products/:id` | Admin | Delete product |
| POST | `/api/orders` | User | Place order |
| GET | `/api/orders/my` | User | View own orders |
| GET | `/api/orders` | Admin | View all orders |
| PATCH | `/api/orders/:id/status` | Admin | Update order status |

Protected endpoints expect `Authorization: Bearer <token>`.

## Project structure

```text
ecommerce-web-application/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── .env.example
├── .gitignore
├── package.json
├── seed-admin.js
├── server.js
└── README.md
```

## Notes for a production version

Before deploying for real customers, add request rate limiting, stronger input validation, CSRF strategy where applicable, secure HTTPS cookies or carefully managed tokens, inventory transaction handling, image upload/storage, email notifications, payment-provider integration, automated tests, logging, and deployment secrets management. Use MongoDB transactions for reliable stock updates in a production checkout flow.
